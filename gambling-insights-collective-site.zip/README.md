# Gambling Insights Collective website

This is a simple static website ready for GitHub Pages.

## Publish it for free

1. Create a GitHub account at github.com.
2. Create a new repository called `gambling-insights-collective`.
3. Upload `index.html` from this folder.
4. Open the repository's **Settings**.
5. Choose **Pages** in the left menu.
6. Under **Build and deployment**, select **Deploy from a branch**.
7. Select branch **main** and folder **/(root)**, then save.
8. GitHub will show the public website address once Pages is enabled.

The survey button already points to:
https://forms.cloud.microsoft/r/hs4ANdJcuw
